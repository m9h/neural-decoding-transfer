from typing import Callable, Dict, Iterable, List, Optional
import time
import subprocess
import logging
from dataclasses import dataclass
from collections import defaultdict
import torch
import pandas as pd
from rich import print as rprint
import torchmetrics
import torch_brain
from torch_brain.registry import ModalitySpec, DataType
from torch_brain.utils.stitcher import stitch

try:
    import lightning as L

    LIGHTNING_AVAILABLE = True
except ImportError:
    LIGHTNING_AVAILABLE = False

    class DummyCallback:
        pass

    L = type("L", (), {"Callback": DummyCallback})

try:
    import wandb
except ImportError:
    wandb = None


def _check_lightning_available(cls):
    """Raise an error if Lightning is not available."""
    if not LIGHTNING_AVAILABLE:
        raise ImportError(
            f"Lightning is not installed. Please install it with "
            f"`pip install lightning~=2.3` to use {cls.__name__}."
        )


class EpochTimeLogger(L.Callback):
    r"""Lightning callback to log the time taken for each epoch.
    Args:
        enable (bool, optional): Whether to enable the callback. Defaults to `True`.
    """

    def __init__(self, enable=True):
        _check_lightning_available(self.__class__)
        self.enable = enable

    def on_train_epoch_start(self, trainer, pl_module):
        if self.enable:
            self.start_time = time.time()

    def on_train_epoch_end(self, trainer, pl_module):
        if self.enable:
            epoch_time = time.time() - self.start_time
            pl_module.log("epoch_time", epoch_time, sync_dist=True)


class ModelWeightStatsLogger(L.Callback):
    r"""Lightning callback to log the mean and standard deviation of the weights and
    gradients of the model.
    Args:
        enable (bool, optional): Whether to enable the callback. Defaults to `True`.
        grads (bool, optional): Whether to log the statistics of gradients.
            Defaults to `True`.
        module_name (str, optional): The name of the :class:`torch.nn.Module` object inside your
            :class:`lightning.LightningModule` object to log the statistics of. Defaults to "model".
            This name is prefixed to the keys in the logs, allowing logging the statistics
            of multiple modules with multiple instances of this callback.
    """

    def __init__(self, enable=True, grads=True, module_name="model", every_n_epoch=1):
        _check_lightning_available(self.__class__)
        self.enable = enable
        self.grads = grads
        self.module_name = module_name
        self.every_n_epoch = every_n_epoch

    def on_train_epoch_end(self, trainer, pl_module):
        if self.enable:
            if pl_module.current_epoch % self.every_n_epoch != 0:
                return

            model = getattr(pl_module, self.module_name)
            for tag, value in model.named_parameters():
                pl_module.log(
                    f"{self.module_name}_weights/mean_{tag}",
                    value.mean(),
                    sync_dist=True,
                )
                if len(value) > 1:
                    pl_module.log(
                        f"{self.module_name}_weights/std_{tag}",
                        value.std(),
                        sync_dist=True,
                    )
                if self.grads and value.grad is not None:
                    pl_module.log(
                        f"{self.module_name}_grads/mean_{tag}",
                        value.grad.mean(),
                        sync_dist=True,
                    )


class MemInfo(L.Callback):
    r"""Lightning callback to print the memory information of the system at the
    beginning of the training. This uses the `cat /proc/meminfo` command to get the
    memory information.
    """

    def on_train_start(self, trainer, pl_module):
        _check_lightning_available(self.__class__)
        # Log the output of `cat /proc/meminfo` using a shell script.
        try:
            # Execute the command and capture its output
            result = subprocess.run(
                ["cat", "/proc/meminfo"],
                capture_output=True,
                text=True,
                check=True,
            )
            result = result.stdout
        except subprocess.CalledProcessError as e:
            print(f"Command failed with error: {e}")
            result = ""

        # Log the output
        logging.info(f"Memory info: \n{result}")


@dataclass
class DataForDecodingStitchEvaluator:
    r"""A batch's worth of data for :class:`DecodingStitchEvaluator`"""

    timestamps: torch.FloatTensor  # B x T_max
    preds: torch.FloatTensor  # B x T_max x D_output
    targets: torch.FloatTensor  # B x T_max x D_output
    eval_masks: torch.BoolTensor  # B x T_max
    session_ids: List[str]  # A list of session ID strings, 1 for each sample in batch
    absolute_starts: torch.Tensor  # Batch


class DecodingStitchEvaluator(L.Callback):
    r"""A convenient stitching and evaluation framework to use when:
     1. Your model outputs have associated timestamps
     2. And your sampling strategy involves overlapping time windows, requiring
        stitching to coalesce the predictions and targets before computing the
        evaluation metric.
     3. (Optional) You are training on multiple sessions/recordings and want to
        compute metrics for each session individually.

    This callback handles the stitching of the predictions and targets for each
    session and computes the metric for each session. The average metric value
    across all sessions is also computed and logged.
    Since the stitching is done only on tensors on the same GPU, sequences that are
    split across multiple GPUs will not be stitched together. In this case, it is
    recommended to use a stitching-aware sampler like
    :class:`~torch_brain.data.sampler.DistributedStitchingFixedWindowSampler`
    which ensures that the sequences are split across GPUs in a way that allows for
    correct stitching.

    This callback is called _after_ the validation_step, and expects you to return a
    :class:`~DataForDecodingStitchEvaluator` object from the validation_step lightning
    module method.
    Please refer to the examples/poyo/train.py script for an example of how to write
    such a validation_step(...) function.

    This callback operates by maintaining a cache of the predictions, targets, and
    timestamps for each session. This cache is updated at the end of each batch.
    Finally, at the end of the epoch, the cache is coalesced and the metric is
    computed for each session.
    """

    def __init__(
        self,
        session_ids: Iterable[str],
        modality_spec: Optional[ModalitySpec] = None,
        metric_factory: Optional[Callable[[int], ModalitySpec]] = None,
        quiet=False,
    ):
        r"""
        Args:
            session_ids: An iterable of session IDs for which the metrics are to be computed.
            modality_spec: (Optional) The modality specification for the task. Either this
                or metric_factory must be provided.
            metric_factory: (Optional) A callable that returns an instance of the metric to be used.
                If not provided, the metric is inferred based on the modality_spec.
            quiet: If True, disables the logging of the metrics to the console.
        """
        _check_lightning_available(self.__class__)
        self.quiet = quiet

        if metric_factory is not None:
            pass
        elif modality_spec.type == DataType.CONTINUOUS:
            metric_factory = lambda: torchmetrics.R2Score()
        elif modality_spec.type in [DataType.BINARY, DataType.MULTINOMIAL]:
            metric_factory = lambda: torchmetrics.Accuracy(
                task="multiclass", num_classes=modality_spec.dim
            )
        else:
            raise ValueError(f"Unsupported datatype: {modality_spec.type}")

        self.metrics = {k: metric_factory() for k in session_ids}

        self.dim = modality_spec.dim
        self.data_type = modality_spec.type

    def on_validation_epoch_start(self, trainer, pl_module):
        # Cache to store the predictions, targets, and timestamps for each
        # validation step. This will be coalesced at the end of the validation,
        # using the stitch function.
        self.cache = defaultdict(
            lambda: {
                "pred": [],
                "target": [],
                "timestamps": [],
            }
        )

    def on_validation_batch_end(
        self,
        trainer: L.Trainer,
        pl_module: L.LightningModule,
        data: DataForDecodingStitchEvaluator,
        *args,
        **kwargs,
    ):
        # Update the cache with the predictions, targets, and timestamps
        batch_size = len(data.timestamps)
        for i in range(batch_size):
            mask = data.eval_masks[i]
            session_id = data.session_ids[i]
            absolute_start = data.absolute_starts[i]

            pred = data.preds[i][mask]
            target = data.targets[i][mask]
            timestamps = data.timestamps[i][mask] + absolute_start

            self.cache[session_id]["pred"].append(pred.detach())
            self.cache[session_id]["target"].append(target.detach())
            self.cache[session_id]["timestamps"].append(timestamps.detach())

    def on_validation_epoch_end(self, trainer, pl_module, prefix="val"):
        # compute metric for each session
        metrics = {}
        for session_id, metric_fn in self.metrics.items():
            cache = self.cache[session_id]
            if len(cache["pred"]) > 0:
                pred = torch.cat(cache["pred"])
                target = torch.cat(cache["target"])
                timestamps = torch.cat(cache["timestamps"])

                stitched_pred = stitch(timestamps, pred)[1]
                stitched_target = stitch(timestamps, target)[1]

                metric_fn.to(pl_module.device).update(stitched_pred, stitched_target)
            else:
                if self.data_type == DataType.CONTINUOUS:
                    metric_fn.to(pl_module.device).update(
                        torch.empty(0, self.dim, device=pl_module.device),
                        torch.empty(0, self.dim, device=pl_module.device),
                    )
                else:
                    metric_fn.to(pl_module.device).update(
                        torch.empty(0, self.dim, device=pl_module.device),
                        torch.empty(0, device=pl_module.device),
                    )

            metrics[session_id] = metric_fn.compute()
            metric_fn.reset()

        # compute the average metric
        metrics[f"average_{prefix}_metric"] = torch.tensor(
            list(metrics.values())
        ).mean()

        # log the metrics
        self.log_dict(metrics)

        metrics_data = []
        for metric_name, metric_value in metrics.items():
            metrics_data.append({"metric": metric_name, "value": metric_value.item()})

        metrics_df = pd.DataFrame(metrics_data)

        if trainer.is_global_zero:
            if not self.quiet:
                logging.info(f"Logged {len(metrics)} {prefix} metrics.")
                rprint(metrics_df)

            for logger in trainer.loggers:
                if isinstance(logger, L.pytorch.loggers.TensorBoardLogger):
                    logger.experiment.add_text(
                        f"{prefix}_metrics", metrics_df.to_markdown()
                    )
                if (
                    isinstance(logger, L.pytorch.loggers.WandbLogger)
                    and wandb is not None
                ):
                    logger.experiment.log(
                        {f"{prefix}_metrics": wandb.Table(dataframe=metrics_df)}
                    )

    def on_test_epoch_start(self, *args, **kwargs):
        self.on_validation_epoch_start(*args, **kwargs)

    def on_test_batch_end(self, *args, **kwargs):
        self.on_validation_batch_end(*args, **kwargs)

    def on_test_epoch_end(self, *args, **kwargs):
        self.on_validation_epoch_end(*args, **kwargs, prefix="test")


@dataclass
class DataForMultiTaskDecodingStitchEvaluator:
    r"""A batch's worth of data for :class:`MultiTaskDecodingStitchEvaluator`"""

    timestamps: torch.FloatTensor  # B x T_max
    preds: List[Dict[str, torch.Tensor]]  # B-long list, Dict keys are task names
    targets: Dict[str, torch.Tensor]  # Keyed by task names, concatenated across batch
    decoder_indices: torch.LongTensor  # B x T_max
    # eval_masks: Keyed by task names, each tensor is mask that can be applied to a
    # task-concatenated tensor of predictions (look at output format of
    # `torch_brain.nn.multitask_readout.MultitaskReadout`)
    eval_masks: Dict[str, torch.BoolTensor]
    session_ids: List[str]  # A list of session ID strings, 1 for each sample in batch
    absolute_starts: torch.Tensor  # Batch


class MultiTaskDecodingStitchEvaluator(L.Callback):
    def __init__(self, metrics: dict):
        _check_lightning_available(self.__class__)
        self.metrics = metrics

    def on_validation_epoch_start(self, trainer, pl_module):
        self._setup_cache(trainer, mode="val")

    def on_validation_batch_end(
        self,
        trainer: L.Trainer,
        pl_module: L.LightningModule,
        data: DataForMultiTaskDecodingStitchEvaluator,
        *args,
        **kwargs,
    ):
        # update the cache with the predictions and targets
        for readout_index in torch.unique(data.decoder_indices):
            if readout_index.item() == 0:
                # skip the padding token
                continue

            mask = data.decoder_indices == readout_index
            readout_id = torch_brain.get_modality_by_id(readout_index.item())

            token_sample_idx = torch.where(mask)[0]

            for i in torch.unique(token_sample_idx):
                pred = data.preds[i][readout_id]
                target = data.targets[readout_id][token_sample_idx == i]
                timestamps = (
                    data.timestamps[mask][token_sample_idx == i]
                    + data.absolute_starts[i]
                )
                eval_mask = data.eval_masks[readout_id][token_sample_idx == i]

                timestamps = timestamps[eval_mask]
                pred = pred[eval_mask]
                target = target[eval_mask]

                seq_idx = self.sequence_index[self.sample_ptr + i]
                self.cache[seq_idx]["pred"][readout_id].append(pred.detach().cpu())
                self.cache[seq_idx]["target"][readout_id].append(target.detach().cpu())
                self.cache[seq_idx]["timestamps"][readout_id].append(
                    timestamps.detach().cpu()
                )

        # update counter then check if the cache should be flushed
        for i in range(len(data.preds)):
            j = self.sequence_index[self.sample_ptr]
            self.counter[j] += 1
            self.sample_ptr += 1

            if self.counter[j] >= self.cache_flush_threshold[j]:
                self.flush_cache(j, session_id=data.session_ids[i])

    def flush_cache(self, i, session_id):
        for task_name in self.cache[i]["pred"].keys():
            pred = torch.cat(self.cache[i]["pred"][task_name])
            timestamps = torch.cat(self.cache[i]["timestamps"][task_name])
            target = torch.cat(self.cache[i]["target"][task_name])

            # Pool data wherever timestamps overlap
            stitched_pred = stitch(timestamps, pred)[1]
            stitched_target = stitch(timestamps, target)[1]

            if target.dtype == torch.long:
                stitched_target = torch.round(stitched_target).long()

            for metric_name in self.metrics[session_id][task_name].keys():
                self.metrics[session_id][task_name][metric_name].update(
                    stitched_pred, stitched_target
                )

        # delete the cache to free memory
        self.cache[i] = None

    def on_validation_epoch_end(self, trainer, pl_module, prefix="val"):
        # check that all caches have been flushed
        for i, cache in enumerate(self.cache):
            if cache is not None:
                raise RuntimeError(
                    f"Cache at index {i} was not flushed before end of validation epoch. "
                    "This likely indicates a bug in the cache flushing logic."
                )

        metrics = {}
        per_task_values: Dict[str, List[torch.Tensor]] = defaultdict(list)
        for recording_id in self.metrics.keys():
            for task_name in self.metrics[recording_id].keys():
                for metric_name in self.metrics[recording_id][task_name].keys():
                    value = (
                        self.metrics[recording_id][task_name][metric_name]
                        .to(pl_module.device)
                        .compute()
                    )
                    metrics[f"{recording_id}/{task_name}/{metric_name}/{prefix}"] = (
                        value
                    )
                    per_task_values[task_name].append(value)
                    self.metrics[recording_id][task_name][metric_name].reset()
                    self.metrics[recording_id][task_name][metric_name].to("cpu")

        # compute the average metric
        metrics[f"average_{prefix}_metric"] = torch.tensor(
            list(metrics.values())
        ).mean()

        # compute per-task averages across recordings/metrics
        for task_name, values in per_task_values.items():
            metrics[f"average_{task_name}_{prefix}_metric"] = torch.tensor(
                values
            ).mean()

        # log the metrics
        self.log_dict(metrics)
        logging.info(f"Logged {len(metrics)} {prefix} metrics.")

        metrics_data = []
        for metric_name, metric_value in metrics.items():
            metrics_data.append({"metric": metric_name, "value": metric_value.item()})

        metrics_df = pd.DataFrame(metrics_data)
        rprint(metrics_df)

        if trainer.is_global_zero:
            for logger in trainer.loggers:
                if isinstance(logger, L.pytorch.loggers.TensorBoardLogger):
                    logger.experiment.add_text(
                        f"{prefix}_metrics", metrics_df.to_markdown()
                    )
                if (
                    isinstance(logger, L.pytorch.loggers.WandbLogger)
                    and wandb is not None
                ):
                    logger.experiment.log(
                        {f"{prefix}_metrics": wandb.Table(dataframe=metrics_df)}
                    )

    def on_test_epoch_start(self, trainer, pl_module):
        self._setup_cache(trainer, mode="test")

    def on_test_batch_end(self, *args, **kwargs):
        self.on_validation_batch_end(*args, **kwargs)

    def on_test_epoch_end(self, *args, **kwargs):
        self.on_validation_epoch_end(*args, **kwargs, prefix="test")

    def _setup_cache(self, trainer, mode: str = "val"):
        if mode == "val":
            self.sequence_index = trainer.datamodule.val_sequence_index
        elif mode == "test":
            self.sequence_index = trainer.datamodule.test_sequence_index
        else:
            raise ValueError(f"Invalid mode: {mode}")

        num_sequences = self.sequence_index.max().item() + 1
        self.sample_ptr = 0

        self.cache = [
            {
                "target": defaultdict(list),
                "pred": defaultdict(list),
                "timestamps": defaultdict(list),
            }
            for _ in range(num_sequences)
        ]

        self.counter = [0] * num_sequences
        # set the target of the couter based on unique in sequence_index
        # use torch.unique to get the count
        _, self.cache_flush_threshold = torch.unique(
            self.sequence_index, return_counts=True
        )
