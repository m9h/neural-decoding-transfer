User Guide
==========

.. toctree::
   :maxdepth: 1

   installation
   sampling/index
