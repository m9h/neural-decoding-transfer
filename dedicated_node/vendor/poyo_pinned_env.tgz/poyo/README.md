# POYO 🧠
Official codebase for POYO published at NeurIPS 2023
[[project page]](https://poyo-brain.github.io/)
[[arxiv]](https://arxiv.org/abs/2310.16046)

### Installation

First, install `uv` by following the steps [here](https://docs.astral.sh/uv/getting-started/installation/). Then, create your Python environment:

```bash
uv venv venv -p 3.11
source venv/bin/activate
uv pip install -r requirements.txt
```

### Training POYO-MP
To train POYO-MP you first need to download and process the [`perich_miller_population_2018`](https://brainsets.readthedocs.io/en/latest/glossary/brainsets.html#perich-miller-population-2018) data using [brainsets](https://github.com/neuro-galaxy/brainsets).

```bash
brainsets config --raw-dir ./data/raw --processed-dir ./data/processed
brainsets prepare perich_miller_population_2018
```

Then you can train POYO-MP by running:

```bash
python train.py --config-name train_poyo_mp.yaml
```

Checkout `configs/base.yaml` and `configs/train_poyo_mp.yaml` for all configurations available.

### Training POYO-1
To train POYO-1 you first need to download all datasets using `brainsets`.

```bash
brainsets config --raw-dir ./data/raw --processed-dir ./data/processed
brainsets prepare perich_miller_population_2018
brainsets prepare churchland_shenoy_neural_2012
brainsets prepare flint_slutzky_accurate_2012
brainsets prepare odoherty_sabes_nonhuman_2017
```

Then you can train POYO-1 by running:

```bash
python train.py --config-name train_poyo_1.yaml
```

Checkout `configs/base.yaml` and `configs/train_poyo_1.yaml` for all configurations available.

## Cite
Please cite [our paper](https://papers.nips.cc/paper_files/paper/2023/hash/8ca113d122584f12a6727341aaf58887-Abstract-Conference.html) if you use this code in your own work:

```bibtex
@inproceedings{
    azabou2023unified,
    title={A Unified, Scalable Framework for Neural Population Decoding},
    author={Mehdi Azabou and Vinam Arora and Venkataramana Ganesh and Ximeng Mao and Santosh Nachimuthu and Michael Mendelson and Blake Richards and Matthew Perich and Guillaume Lajoie and Eva L. Dyer},
    booktitle={Thirty-seventh Conference on Neural Information Processing Systems},
    year={2023},
}
```
