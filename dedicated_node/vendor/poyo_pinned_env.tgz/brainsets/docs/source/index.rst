.. brainsets documentation master file, created by
   sphinx-quickstart on Sun Jan  7 15:07:22 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

**brainsets**
============================

.. image:: https://img.shields.io/pypi/v/brainsets?color=blue&logo=pypi&logoColor=white
   :target: https://pypi.org/project/brainsets/
   :alt: PyPI Package

.. image:: https://img.shields.io/badge/GitHub-Repository-black?logo=github&logoColor=white
   :target: https://github.com/neuro-galaxy/brainsets
   :alt: GitHub Repository

.. image:: https://img.shields.io/badge/GitHub-Issues-black?logo=github&logoColor=white
   :target: https://github.com/neuro-galaxy/brainsets/issues
   :alt: GitHub Issues

.. image:: https://img.shields.io/discord/1338561153089146962?label=Discord&logo=discord
   :target: https://discord.gg/kQNKA6B8ZC
   :alt: Discord

**brainsets** is a Python package for processing neural data into a standardized format.


If you encounter any bugs or have feature requests, please submit them to our
`GitHub Issues page <https://github.com/neuro-galaxy/brainsets/issues>`_.

----

.. toctree::
   :maxdepth: 1
   :caption: Get Started

   concepts/installation

.. toctree::
   :maxdepth: 1
   :caption: Tutorials

   concepts/using_existing_data
   concepts/prepare_data
   concepts/create_pipeline
   concepts/neuroprobe

.. toctree::
   :maxdepth: 1
   :caption: Glossary

   glossary/brainsets

.. toctree::
   :maxdepth: 1
   :caption: CLI Reference

   Commands <cli/commands>

.. toctree::
   :maxdepth: 2
   :caption: Package Reference

   package/brainsetpipeline
   package/descriptions
   package/taxonomy
   package/utils
   package/core
   package/processing

.. toctree::
   :maxdepth: 2
   :caption: Datasets

   datasets/index
